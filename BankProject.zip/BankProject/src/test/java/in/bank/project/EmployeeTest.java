package in.bank.project;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;

import in.bank.project.Bankspringbootapplication;
import in.bank.project.model.Employee;
import in.bank.project.repository.BankRepository;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
	public class EmployeeTest {
		
		@Autowired
		private BankRepository repo;
		
		@Test
		@Rollback(false)
		public void testsaveEmployee() {
			Employee employee = new Employee("hari","124587451","hari@1999","harika","employee","loan","h");
			Employee savedemployee = repo.save(employee);
			assertNotNull(savedemployee);
			
		}
		
		@Test
		public void testListEmployees() { 
		 List<Employee> employees = (List<Employee>) repo.findAll();
		 for ( Employee employee : employees)
		 {
			 System.out.println(employee);
		 }
	    	assertThat(employees).size().isGreaterThan(0);
		}
		
}